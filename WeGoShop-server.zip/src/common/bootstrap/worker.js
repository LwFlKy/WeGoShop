// invoked in worker
require('../common.js')