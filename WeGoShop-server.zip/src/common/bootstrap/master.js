// invoked in master
require('../common.js')