// default config
module.exports = {
  // 可以公开访问的Controller
  publicController: {
    admin: [
      'admin/auth'
    ]
  },

  // 可以公开访问的Action
  publicAction: [
  ]
};
